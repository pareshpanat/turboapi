# TurboAPI

TurboAPI is a small, fast ASGI web framework built from scratch (stdlib-only) with a focus on predictable performance.

## Features
- Trie router with `{param}` path params
- `APIRouter` composition with prefixes/tags via `include_router()`
- Compiled route plans (signature inspection happens at route registration, not per request)
- Dependency injection with `Depends()` including nested and yield-based dependencies
- Built-in validation with `Model` + `field()` (supports `Annotated`, `Literal`, `Enum`, `datetime`, `UUID`, `Decimal`)
- Security primitives: `api_key_auth()`, `bearer_auth()`, `jwt_auth()` with OpenAPI security schemas
- OpenAPI at `/openapi.json`
- Swagger UI at `/docs` and ReDoc at `/redoc`
- Lifespan startup/shutdown handlers
- Custom exception handlers with `@app.exception_handler(...)`
- Reliability defaults: request timeout, max body size, max concurrency
- CI release gates: Python matrix tests/lint + package build and `twine check`, with trusted publishing workflow

## Install
```bash
pip install -e ".[dev]"
```

## Run example
```bash
uvicorn examples.app:app --reload
```

Open:
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/openapi.json

## License
Apache-2.0 (see LICENSE).
