import pytest
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from typing import Annotated, Literal
from uuid import UUID
from turbo.models import Model, field, compile_model_validator
from turbo.errors import HTTPError

class U(Model):
    name: str = field(min_len=2)

def test_min_len():
    v=compile_model_validator(U)
    with pytest.raises(HTTPError):
        v({'name':'A'})

class Role(str, Enum):
    ADMIN = "admin"
    USER = "user"

class Advanced(Model):
    role: Role
    code: Literal["A", "B"]
    when: datetime
    day: date
    amount: Decimal
    uid: UUID
    short: Annotated[str, field(min_len=2)]

def test_advanced_types_are_validated():
    v = compile_model_validator(Advanced)
    result = v({
        "role": "admin",
        "code": "A",
        "when": "2026-01-01T12:00:00Z",
        "day": "2026-01-01",
        "amount": "12.34",
        "uid": "2dc3f898-7f9e-4018-b94f-fdb65586df3f",
        "short": "ok",
    })
    assert result["role"].value == "admin"
    assert isinstance(result["when"], datetime)
    assert isinstance(result["day"], date)
    assert isinstance(result["amount"], Decimal)
    assert isinstance(result["uid"], UUID)

def test_advanced_literal_validation_error():
    v = compile_model_validator(Advanced)
    with pytest.raises(HTTPError):
        v({
            "role": "admin",
            "code": "C",
            "when": "2026-01-01T12:00:00Z",
            "day": "2026-01-01",
            "amount": "12.34",
            "uid": "2dc3f898-7f9e-4018-b94f-fdb65586df3f",
            "short": "ok",
        })
