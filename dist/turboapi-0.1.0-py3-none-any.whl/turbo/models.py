from __future__ import annotations
import re
import types
from dataclasses import dataclass
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import Any, Dict, Optional, Annotated, Union, get_args, get_origin, Literal
from uuid import UUID
from .errors import HTTPError

_MISSING = object()

@dataclass(frozen=True, slots=True)
class FieldInfo:
    min_len: Optional[int]=None
    max_len: Optional[int]=None
    ge: Optional[float]=None
    le: Optional[float]=None
    regex: Optional[str]=None

def field(*, min_len=None, max_len=None, ge=None, le=None, regex=None)->Any:
    return FieldInfo(min_len=min_len,max_len=max_len,ge=ge,le=le,regex=regex)

class Model:
    @classmethod
    def schema(cls)->Dict[str,Any]:
        return model_to_json_schema(cls)

def _union_args(tp):
    o = get_origin(tp)
    if o in (Union, types.UnionType):
        return get_args(tp)
    return ()

def _split_annotated(tp):
    if get_origin(tp) is Annotated:
        args = get_args(tp)
        base = args[0]
        meta = args[1:]
        fi = next((m for m in meta if isinstance(m, FieldInfo)), None)
        return base, fi
    return tp, None

def is_optional(tp)->bool:
    return type(None) in _union_args(tp)

def unwrap_optional(tp):
    args = [a for a in _union_args(tp) if a is not type(None)]
    if args:
        if len(args) == 1:
            return args[0]
        return Union[tuple(args)]
    return tp

_VALIDATOR_CACHE: Dict[type,Any] = {}

def compile_model_validator(model_cls:type[Model]):
    if model_cls in _VALIDATOR_CACHE:
        return _VALIDATOR_CACHE[model_cls]
    anns=getattr(model_cls,"__annotations__",{})
    compiled=[]
    for name,tp in anns.items():
        base_tp, ann_fi = _split_annotated(tp)
        dv=getattr(model_cls,name,_MISSING)
        fi = None
        real_default = _MISSING
        if isinstance(dv, FieldInfo):
            fi = dv
        elif dv is not _MISSING:
            real_default = dv
        if ann_fi is not None:
            fi = ann_fi
        compiled.append((name,base_tp,fi,real_default))

    def validate(data:Any)->Dict[str,Any]:
        if data is None:
            raise HTTPError(422,"Body required")
        if not isinstance(data, dict):
            raise HTTPError(422,"Invalid JSON body",{"expected":"object"})
        out={}
        for name,tp,fi,real_default in compiled:
            opt=is_optional(tp)
            base=unwrap_optional(tp)
            if name not in data:
                if real_default is not _MISSING:
                    out[name]=real_default
                    continue
                if opt:
                    out[name]=None
                    continue
                raise HTTPError(422,"Missing field",{"field":name})
            val = data[name]
            if val is None and opt:
                out[name] = None
                continue
            out[name]=validate_value(name, val, base, fi)
        return out
    _VALIDATOR_CACHE[model_cls]=validate
    return validate

def _validate_literal(name: str, val: Any, tp: Any):
    allowed = get_args(tp)
    if val not in allowed:
        raise HTTPError(422, "Invalid literal value", {"field": name, "allowed": list(allowed)})
    return val

def _validate_union(name: str, val: Any, tp: Any):
    errors = []
    for arg in _union_args(tp):
        if arg is type(None):
            continue
        try:
            return validate_value(name, val, arg, None)
        except HTTPError as exc:
            errors.append(exc.message)
    raise HTTPError(422, "Invalid union field value", {"field": name, "errors": errors})

def validate_value(name:str, val:Any, tp:Any, fi:Optional[FieldInfo]):
    if isinstance(tp,type) and issubclass(tp, Model):
        return compile_model_validator(tp)(val)

    origin=get_origin(tp)
    args=get_args(tp)
    if _union_args(tp):
        return _validate_union(name, val, tp)
    if origin is Literal:
        return _validate_literal(name, val, tp)
    if origin is list:
        if not isinstance(val,list):
            raise HTTPError(422,"Invalid field type",{"field":name,"expected":"array"})
        inner=args[0] if args else Any
        return [validate_value(name,x,inner,None) for x in val]
    if origin is dict:
        if not isinstance(val,dict):
            raise HTTPError(422,"Invalid field type",{"field":name,"expected":"object"})
        inner=args[1] if len(args)==2 else Any
        return {str(k): validate_value(name,v,inner,None) for k,v in val.items()}

    if isinstance(tp, type) and issubclass(tp, Enum):
        try:
            return tp(val)
        except Exception:
            allowed = [m.value for m in tp]
            raise HTTPError(422, "Invalid enum value", {"field": name, "allowed": allowed})
    if tp is str:
        if not isinstance(val,str):
            raise HTTPError(422,"Invalid field type",{"field":name,"expected":"string"})
        if fi:
            if fi.min_len is not None and len(val)<fi.min_len:
                raise HTTPError(422,"String too short",{"field":name})
            if fi.max_len is not None and len(val)>fi.max_len:
                raise HTTPError(422,"String too long",{"field":name})
            if fi.regex is not None and re.search(fi.regex,val) is None:
                raise HTTPError(422,"String does not match pattern",{"field":name})
        return val
    if tp is int:
        if not isinstance(val,int) or isinstance(val,bool):
            raise HTTPError(422,"Invalid field type",{"field":name,"expected":"integer"})
        if fi:
            if fi.ge is not None and val<fi.ge:
                raise HTTPError(422,"Number too small",{"field":name})
            if fi.le is not None and val>fi.le:
                raise HTTPError(422,"Number too large",{"field":name})
        return val
    if tp is float:
        if not isinstance(val,(int,float)) or isinstance(val,bool):
            raise HTTPError(422,"Invalid field type",{"field":name,"expected":"number"})
        v=float(val)
        if fi:
            if fi.ge is not None and v<fi.ge:
                raise HTTPError(422,"Number too small",{"field":name})
            if fi.le is not None and v>fi.le:
                raise HTTPError(422,"Number too large",{"field":name})
        return v
    if tp is Decimal:
        try:
            dec = Decimal(str(val))
        except (InvalidOperation, ValueError):
            raise HTTPError(422, "Invalid field type", {"field": name, "expected": "decimal"})
        if fi:
            num = float(dec)
            if fi.ge is not None and num < fi.ge:
                raise HTTPError(422, "Number too small", {"field": name})
            if fi.le is not None and num > fi.le:
                raise HTTPError(422, "Number too large", {"field": name})
        return dec
    if tp is bool:
        if not isinstance(val,bool):
            raise HTTPError(422,"Invalid field type",{"field":name,"expected":"boolean"})
        return val
    if tp is datetime:
        if not isinstance(val, str):
            raise HTTPError(422, "Invalid field type", {"field": name, "expected": "date-time"})
        try:
            return datetime.fromisoformat(val.replace("Z", "+00:00"))
        except ValueError:
            raise HTTPError(422, "Invalid datetime format", {"field": name})
    if tp is date:
        if not isinstance(val, str):
            raise HTTPError(422, "Invalid field type", {"field": name, "expected": "date"})
        try:
            return date.fromisoformat(val)
        except ValueError:
            raise HTTPError(422, "Invalid date format", {"field": name})
    if tp is time:
        if not isinstance(val, str):
            raise HTTPError(422, "Invalid field type", {"field": name, "expected": "time"})
        try:
            return time.fromisoformat(val)
        except ValueError:
            raise HTTPError(422, "Invalid time format", {"field": name})
    if tp is UUID:
        if not isinstance(val, str):
            raise HTTPError(422, "Invalid field type", {"field": name, "expected": "uuid"})
        try:
            return UUID(val)
        except ValueError:
            raise HTTPError(422, "Invalid uuid format", {"field": name})
    return val

def model_to_json_schema(model_cls:type[Model])->Dict[str,Any]:
    anns=getattr(model_cls,"__annotations__",{})
    required=[]; props={}
    for name,tp in anns.items():
        base_tp, ann_fi = _split_annotated(tp)
        dv=getattr(model_cls,name,_MISSING)
        fi=dv if isinstance(dv, FieldInfo) else ann_fi
        has_default = dv is not _MISSING and not isinstance(dv, FieldInfo)
        opt=is_optional(base_tp)
        if not opt and not has_default:
            required.append(name)
        props[name]=type_to_schema(unwrap_optional(base_tp), fi)
    sch={"type":"object","properties":props}
    if required:
        sch["required"]=required
    return sch

def type_to_schema(tp:Any, fi:Optional[FieldInfo])->Dict[str,Any]:
    tp, ann_fi = _split_annotated(tp)
    fi = ann_fi or fi
    if isinstance(tp,type) and issubclass(tp, Model):
        return model_to_json_schema(tp)
    if _union_args(tp):
        return {"oneOf": [type_to_schema(a, None) for a in _union_args(tp) if a is not type(None)]}
    origin=get_origin(tp)
    args=get_args(tp)
    if origin is Literal:
        vals = list(args)
        val_types = {type(v) for v in vals}
        if len(val_types) == 1:
            one = next(iter(val_types))
            base = type_to_schema(one, None)
            base["enum"] = vals
            return base
        return {"enum": vals}
    if origin is list:
        inner=args[0] if args else Any
        return {"type":"array","items":type_to_schema(inner,None)}
    if origin is dict:
        inner=args[1] if len(args)==2 else Any
        return {"type":"object","additionalProperties":type_to_schema(inner,None)}
    if isinstance(tp, type) and issubclass(tp, Enum):
        values = [m.value for m in tp]
        val_types = {type(v) for v in values}
        if len(val_types) == 1:
            base = type_to_schema(next(iter(val_types)), None)
            base["enum"] = values
            return base
        return {"enum": values}
    if tp is str:
        sch={"type":"string"}
        if fi:
            if fi.min_len is not None:
                sch["minLength"]=fi.min_len
            if fi.max_len is not None:
                sch["maxLength"]=fi.max_len
            if fi.regex is not None:
                sch["pattern"]=fi.regex
        return sch
    if tp is int:
        sch={"type":"integer"}
        if fi:
            if fi.ge is not None:
                sch["minimum"]=fi.ge
            if fi.le is not None:
                sch["maximum"]=fi.le
        return sch
    if tp is float:
        sch={"type":"number"}
        if fi:
            if fi.ge is not None:
                sch["minimum"]=fi.ge
            if fi.le is not None:
                sch["maximum"]=fi.le
        return sch
    if tp is Decimal:
        sch={"type":"string","format":"decimal"}
        if fi:
            if fi.ge is not None:
                sch["minimum"]=fi.ge
            if fi.le is not None:
                sch["maximum"]=fi.le
        return sch
    if tp is bool:
        return {"type":"boolean"}
    if tp is datetime:
        return {"type":"string", "format":"date-time"}
    if tp is date:
        return {"type":"string", "format":"date"}
    if tp is time:
        return {"type":"string", "format":"time"}
    if tp is UUID:
        return {"type":"string", "format":"uuid"}
    return {"type":"string"}
