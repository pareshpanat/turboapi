from __future__ import annotations
import inspect
from typing import Any, Dict, Set
from .models import Model, model_to_json_schema, type_to_schema

def build_openapi(app, *, title="TurboAPI", version="0.1.0")->Dict[str,Any]:
    components={"schemas":{}, "securitySchemes": {}}
    seen:set[type]=set()
    def model_ref(m:type[Model]): seen.add(m); return {"$ref": f"#/components/schemas/{m.__name__}"}
    def ensure():
        q=list(seen); done=set()
        while q:
            m=q.pop()
            if m in done: continue
            done.add(m)
            components["schemas"][m.__name__]=model_to_json_schema(m)
            for _,tp in getattr(m,"__annotations__",{}).items():
                for nm in _find_models(tp):
                    if nm not in done:
                        seen.add(nm); q.append(nm)
    paths={}
    for r in app._routes:
        if r.internal: continue
        pi=paths.setdefault(r.path,{})
        op={"operationId": r.name, "responses": {}}
        if r.tags:
            op["tags"] = r.tags
        if r.summary:
            op["summary"] = r.summary
        if r.description:
            op["description"] = r.description
        if r.security:
            op["security"] = r.security
        if r.security_schemes:
            for name, scheme in r.security_schemes.items():
                components["securitySchemes"][name] = scheme
        params=[]
        for p in r.param_specs:
            if p.kind in ("request","dep"): continue
            kind = "path" if p.name in r.path_param_names else "query"
            ann = str if (p.annotation is inspect._empty or p.annotation is None) else p.annotation
            schema = model_ref(ann) if (isinstance(ann,type) and issubclass(ann,Model)) else type_to_schema(ann,None)
            params.append({"name":p.name,"in":kind,"required": (kind=="path") or (p.default is inspect._empty),"schema":schema})
        if params: op["parameters"]=params
        if r.request_body_model is not None:
            op["requestBody"]={"required":True,"content":{"application/json":{"schema":model_ref(r.request_body_model)}}}
        if r.responses:
            for code, payload in r.responses.items():
                code_key = str(code)
                if isinstance(payload, dict):
                    op["responses"][code_key] = payload
                else:
                    op["responses"][code_key] = {"description": str(payload)}
        if r.response_model is not None and isinstance(r.response_model,type) and issubclass(r.response_model,Model):
            op["responses"]["200"]={"description":"OK","content":{"application/json":{"schema":model_ref(r.response_model)}}}
        elif "200" not in op["responses"]:
            op["responses"]["200"]={"description":"OK"}
        pi[r.method.lower()]=op
    ensure()
    if not components["securitySchemes"]:
        components.pop("securitySchemes", None)
    return {"openapi":"3.0.3","info":{"title":title,"version":version},"paths":paths,"components":components}

def _find_models(tp)->Set[type]:
    out=set()
    if isinstance(tp,type) and issubclass(tp,Model): out.add(tp)
    for a in getattr(tp,"__args__",()) or ():
        out |= _find_models(a)
    return out
