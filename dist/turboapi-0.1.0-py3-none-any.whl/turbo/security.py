from __future__ import annotations
import base64
import hashlib
import hmac
import json
import time
from typing import Any, Optional
from .errors import HTTPError
from .request import Request

def _mark_security(dep, *, scheme_name: str, scheme: dict[str, Any], scopes: Optional[list[str]] = None):
    dep.__turbo_security_requirement__ = {scheme_name: list(scopes or [])}
    dep.__turbo_security_scheme__ = (scheme_name, scheme)
    return dep

def _extract_bearer_token(req: Request, *, auto_error: bool) -> Optional[str]:
    header = req.headers.get("authorization", "")
    if not header:
        if auto_error:
            raise HTTPError(401, "Missing Authorization header")
        return None
    parts = header.split(" ", 1)
    if len(parts) != 2 or parts[0].lower() != "bearer" or not parts[1].strip():
        raise HTTPError(401, "Invalid Authorization header")
    return parts[1].strip()

def api_key_auth(header_name: str = "x-api-key", *, scheme_name: str = "ApiKeyAuth", auto_error: bool = True):
    header_key = header_name.lower()
    async def _dep(req: Request):
        val = req.headers.get(header_key)
        if not val:
            if auto_error:
                raise HTTPError(401, "Missing API key", {"header": header_name})
            return None
        return val
    return _mark_security(
        _dep,
        scheme_name=scheme_name,
        scheme={"type": "apiKey", "in": "header", "name": header_name},
    )

def bearer_auth(*, scheme_name: str = "BearerAuth", bearer_format: Optional[str] = None, auto_error: bool = True):
    async def _dep(req: Request):
        return _extract_bearer_token(req, auto_error=auto_error)
    scheme = {"type": "http", "scheme": "bearer"}
    if bearer_format:
        scheme["bearerFormat"] = bearer_format
    return _mark_security(_dep, scheme_name=scheme_name, scheme=scheme)

def _b64url_decode(value: str) -> bytes:
    pad = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + pad).encode("ascii"))

def _decode_jwt_hs256(token: str, *, secret: str, issuer: Optional[str], audience: Optional[str], leeway: int) -> dict[str, Any]:
    parts = token.split(".")
    if len(parts) != 3:
        raise HTTPError(401, "Invalid JWT format")
    head_b64, payload_b64, sig_b64 = parts
    try:
        header = json.loads(_b64url_decode(head_b64).decode("utf-8"))
        payload = json.loads(_b64url_decode(payload_b64).decode("utf-8"))
    except Exception:
        raise HTTPError(401, "Invalid JWT payload")
    if header.get("alg") != "HS256":
        raise HTTPError(401, "Unsupported JWT algorithm")
    signing_input = f"{head_b64}.{payload_b64}".encode("ascii")
    expected = hmac.new(secret.encode("utf-8"), signing_input, hashlib.sha256).digest()
    given = _b64url_decode(sig_b64)
    if not hmac.compare_digest(expected, given):
        raise HTTPError(401, "Invalid JWT signature")

    now = int(time.time())
    exp = payload.get("exp")
    if exp is not None and int(exp) < now - int(leeway):
        raise HTTPError(401, "JWT expired")
    nbf = payload.get("nbf")
    if nbf is not None and int(nbf) > now + int(leeway):
        raise HTTPError(401, "JWT not active yet")
    iat = payload.get("iat")
    if iat is not None and int(iat) > now + int(leeway):
        raise HTTPError(401, "JWT issued-at is in the future")
    if issuer is not None and payload.get("iss") != issuer:
        raise HTTPError(401, "Invalid JWT issuer")
    if audience is not None:
        aud = payload.get("aud")
        if isinstance(aud, list):
            if audience not in aud:
                raise HTTPError(401, "Invalid JWT audience")
        elif aud != audience:
            raise HTTPError(401, "Invalid JWT audience")
    return payload

def jwt_auth(secret: str, *, scheme_name: str = "JWTAuth", issuer: Optional[str] = None, audience: Optional[str] = None, leeway: int = 0, auto_error: bool = True):
    if not secret:
        raise ValueError("secret is required")
    async def _dep(req: Request):
        token = _extract_bearer_token(req, auto_error=auto_error)
        if token is None:
            return None
        return _decode_jwt_hs256(token, secret=secret, issuer=issuer, audience=audience, leeway=leeway)
    return _mark_security(
        _dep,
        scheme_name=scheme_name,
        scheme={"type": "http", "scheme": "bearer", "bearerFormat": "JWT"},
    )
