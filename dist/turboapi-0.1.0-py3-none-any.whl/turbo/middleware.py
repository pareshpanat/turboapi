from __future__ import annotations
from typing import Callable, Awaitable, List
Middleware = Callable[..., Awaitable]

class MiddlewareStack:
    def __init__(self): self._mws: List[Middleware] = []
    def add(self, mw: Middleware): self._mws.append(mw)
    def build(self, final_handler):
        handler=final_handler
        for mw in reversed(self._mws):
            nxt=handler
            async def wrapped(req, receive, send, _mw=mw, _next=nxt):
                return await _mw(req, lambda r=req: _next(r, receive, send))
            handler=wrapped
        return handler
