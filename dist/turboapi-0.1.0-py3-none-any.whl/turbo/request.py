from __future__ import annotations
import json
from dataclasses import dataclass
from typing import Dict, Optional
from urllib.parse import parse_qs

@dataclass(slots=True)
class Request:
    scope: dict
    _body: Optional[bytes] = None
    path_params: Optional[Dict[str,str]] = None

    @property
    def method(self)->str: return self.scope["method"]
    @property
    def path(self)->str: return self.scope["path"]

    @property
    def headers(self)->Dict[str,str]:
        out={}
        for k,v in self.scope.get("headers", []):
            out[k.decode("latin1").lower()] = v.decode("latin1")
        return out

    @property
    def query_params(self)->Dict[str,str]:
        raw=self.scope.get("query_string", b"").decode("utf-8","ignore")
        parsed=parse_qs(raw, keep_blank_values=True)
        return {k:(v[0] if v else "") for k,v in parsed.items()}

    async def body(self, receive)->bytes:
        if self._body is not None: return self._body
        chunks=[]; more=True
        while more:
            event=await receive()
            if event["type"]!="http.request": 
                continue
            chunks.append(event.get("body", b""))
            more=bool(event.get("more_body", False))
        self._body=b"".join(chunks)
        return self._body

    async def json(self, receive):
        b=await self.body(receive)
        if not b: return None
        return json.loads(b.decode("utf-8"))
