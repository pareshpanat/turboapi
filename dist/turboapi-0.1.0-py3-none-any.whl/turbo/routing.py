from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, Optional

@dataclass(slots=True)
class Match:
    handler: Callable
    params: Dict[str,str]

class _Node:
    __slots__=("static","param","param_name","handler")
    def __init__(self):
        self.static={}
        self.param=None
        self.param_name=None
        self.handler=None

class Router:
    def __init__(self): self._trees={}
    def add(self, method:str, path:str, handler:Callable):
        method=method.upper()
        if not path.startswith("/"): raise ValueError("path must start with /")
        root=self._trees.setdefault(method, _Node())
        node=root
        for seg in [s for s in path.split("/") if s]:
            if seg.startswith("{") and seg.endswith("}"):
                name=seg[1:-1].strip()
                if node.param is None:
                    node.param=_Node(); node.param_name=name
                node=node.param
            else:
                node=node.static.setdefault(seg, _Node())
        if node.handler is not None: raise ValueError(f"duplicate route: {method} {path}")
        node.handler=handler

    def match(self, method:str, path:str)->Optional[Match]:
        root=self._trees.get(method.upper())
        if root is None: return None
        node=root; params={}
        for seg in [s for s in path.split("/") if s]:
            nxt=node.static.get(seg)
            if nxt is not None:
                node=nxt; continue
            if node.param is not None:
                params[node.param_name or "param"]=seg
                node=node.param; continue
            return None
        if node.handler is None: return None
        return Match(handler=node.handler, params=params)
