from __future__ import annotations
import json
from dataclasses import dataclass
from typing import Iterable, Tuple, Union, Optional, Any

Headers = Iterable[Tuple[bytes, bytes]]
Body = Union[bytes, bytearray, memoryview]

@dataclass(slots=True)
class Response:
    status: int = 200
    headers: Optional[Headers] = None
    body: Body = b""
    async def send(self, send):
        headers = list(self.headers or [])
        await send({"type":"http.response.start","status":self.status,"headers":headers})
        await send({"type":"http.response.body","body":bytes(self.body)})

class TextResponse(Response):
    def __init__(self, text: str, status: int=200, headers: Optional[Headers]=None):
        hdrs=list(headers or [])
        hdrs.append((b"content-type", b"text/plain; charset=utf-8"))
        super().__init__(status=status, headers=hdrs, body=text.encode("utf-8"))

class HTMLResponse(Response):
    def __init__(self, html: str, status: int=200, headers: Optional[Headers]=None):
        hdrs=list(headers or [])
        hdrs.append((b"content-type", b"text/html; charset=utf-8"))
        super().__init__(status=status, headers=hdrs, body=html.encode("utf-8"))

class JSONResponse(Response):
    def __init__(self, data: Any, status: int=200, headers: Optional[Headers]=None, dumps=json.dumps):
        payload=dumps(data, separators=(",",":"), ensure_ascii=False).encode("utf-8")
        hdrs=list(headers or [])
        hdrs.append((b"content-type", b"application/json; charset=utf-8"))
        super().__init__(status=status, headers=hdrs, body=payload)
