import asyncio
from contextlib import asynccontextmanager

@asynccontextmanager
async def timeout(seconds: float):
    if seconds is None or seconds <= 0:
        yield; return
    async with asyncio.timeout(seconds):
        yield
