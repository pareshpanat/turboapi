from __future__ import annotations
import asyncio, inspect
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional
from .routing import Router
from .request import Request
from .response import Response, JSONResponse, TextResponse, HTMLResponse
from .errors import HTTPError
from .middleware import MiddlewareStack
from .utils import timeout
from .deps import Depends, ParamSpec, compile_route_plan, resolve_dependencies
from .models import Model, compile_model_validator
from .openapi import build_openapi

Handler = Callable[..., Awaitable[Any]]

@dataclass(slots=True)
class RouteDef:
    method: str
    path: str
    handler: Handler
    name: Optional[str] = None
    response_model: Optional[Any] = None
    internal: bool = False
    tags: Optional[list[str]] = None
    summary: Optional[str] = None
    description: Optional[str] = None
    responses: Optional[dict[Any, Any]] = None
    security: Optional[list[dict[str, list[str]]]] = None

@dataclass(slots=True)
class Route:
    method: str
    path: str
    handler: Handler
    name: str
    param_specs: list[ParamSpec]
    sig: inspect.Signature
    path_param_names: set[str]
    request_body_model: Optional[type[Model]] = None
    validate_body_fn: Optional[Callable] = None
    response_model: Optional[Any] = None
    validate_response_fn: Optional[Callable] = None
    internal: bool = False
    tags: list[str] | None = None
    summary: Optional[str] = None
    description: Optional[str] = None
    responses: dict[Any, Any] | None = None
    security: list[dict[str, list[str]]] | None = None
    security_schemes: dict[str, dict[str, Any]] | None = None

class APIRouter:
    def __init__(self, *, prefix: str = "", tags: Optional[list[str]] = None):
        if prefix and not prefix.startswith("/"):
            raise ValueError("prefix must start with /")
        self.prefix = prefix.rstrip("/") if prefix not in ("", "/") else ""
        self.tags = list(tags or [])
        self._routes: list[RouteDef] = []

    def route(self, method: str, path: str, *, name: Optional[str] = None, response_model: Optional[Any] = None, internal: bool = False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        def deco(fn: Handler):
            merged_tags = list(dict.fromkeys([*self.tags, *(tags or [])]))
            self._routes.append(RouteDef(method=method.upper(), path=path, handler=fn, name=name, response_model=response_model, internal=internal, tags=merged_tags or None, summary=summary, description=description, responses=responses, security=security))
            return fn
        return deco

    def get(self, path: str, *, name: Optional[str] = None, response_model: Optional[Any] = None, internal: bool = False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        return self.route("GET", path, name=name, response_model=response_model, internal=internal, tags=tags, summary=summary, description=description, responses=responses, security=security)

    def post(self, path: str, *, name: Optional[str] = None, response_model: Optional[Any] = None, internal: bool = False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        return self.route("POST", path, name=name, response_model=response_model, internal=internal, tags=tags, summary=summary, description=description, responses=responses, security=security)

    def put(self, path: str, *, name: Optional[str] = None, response_model: Optional[Any] = None, internal: bool = False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        return self.route("PUT", path, name=name, response_model=response_model, internal=internal, tags=tags, summary=summary, description=description, responses=responses, security=security)

    def delete(self, path: str, *, name: Optional[str] = None, response_model: Optional[Any] = None, internal: bool = False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        return self.route("DELETE", path, name=name, response_model=response_model, internal=internal, tags=tags, summary=summary, description=description, responses=responses, security=security)

class Turbo:
    def __init__(self, *, request_timeout:float=10.0, max_body_bytes:int=1_000_000, max_concurrency:int=200, title:str="TurboAPI", version:str="0.1.0"):
        self.router=Router()
        self.middleware=MiddlewareStack()
        self.request_timeout=request_timeout
        self.max_body_bytes=max_body_bytes
        self._sem=asyncio.Semaphore(max_concurrency)
        self._routes=[]
        self._route_by_handler={}
        self._openapi_cache=None
        self._title=title
        self._version=version
        self._startup_handlers: list[Callable[..., Any]] = []
        self._shutdown_handlers: list[Callable[..., Any]] = []
        self._exception_handlers: dict[type[BaseException], Callable[..., Any]] = {}
        self._install_openapi_and_docs()

    def _install_openapi_and_docs(self):
        @self.get("/openapi.json", internal=True)
        async def _openapi():
            if self._openapi_cache is None:
                self._openapi_cache = build_openapi(self, title=self._title, version=self._version)
            return self._openapi_cache

        @self.get("/docs", internal=True)
        async def _docs():
            html=f'''<!doctype html><html><head><meta charset="utf-8"/><title>{self._title} - Docs</title>
<link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css"/></head>
<body><div id="swagger-ui"></div>
<script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
<script>window.onload=()=>{{SwaggerUIBundle({{url:"/openapi.json",dom_id:"#swagger-ui"}});}};</script>
</body></html>'''
            return HTMLResponse(html)

        @self.get("/redoc", internal=True)
        async def _redoc():
            html=f'''<!doctype html><html><head><meta charset="utf-8"/><title>{self._title} - ReDoc</title></head>
<body><redoc spec-url="/openapi.json"></redoc><script src="https://unpkg.com/redoc@2/bundles/redoc.standalone.js"></script></body></html>'''
            return HTMLResponse(html)

    def route(self, method:str, path:str, *, name:Optional[str]=None, response_model:Optional[Any]=None, internal:bool=False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        method=method.upper()
        def deco(fn:Handler):
            self.router.add(method, path, fn)
            specs,sig=compile_route_plan(fn, request_type=Request)
            path_params=set(seg[1:-1].strip() for seg in path.split("/") if seg.startswith("{") and seg.endswith("}"))
            body_model=None; validate_body_fn=None
            body_candidates=[p for p in specs if p.kind=="auto" and p.annotation is not inspect._empty and isinstance(p.annotation,type) and issubclass(p.annotation,Model)]
            if len(body_candidates)>1:
                raise ValueError("TurboAPI MVP supports at most one body Model parameter per route.")
            if body_candidates:
                param_name=body_candidates[0].name
                body_model=body_candidates[0].annotation
                mv=compile_model_validator(body_model)
                async def _vb(req:Request, receive):
                    data=await req.json(receive)
                    return {param_name: mv(data)}
                validate_body_fn=_vb
            validate_resp=None
            if response_model is not None and isinstance(response_model,type) and issubclass(response_model,Model):
                rv=compile_model_validator(response_model)
                def _vr(obj:Any):
                    if obj is None or not isinstance(obj,dict): raise HTTPError(500,"Response must be a JSON object for response_model")
                    return rv(obj)
                validate_resp=_vr
            inferred_security, security_schemes = _extract_security(specs)
            effective_security = security if security is not None else inferred_security
            r=Route(method,path,fn,name or fn.__name__,specs,sig,path_params,body_model,validate_body_fn,response_model,validate_resp,internal,tags,summary,description,responses,effective_security,security_schemes)
            self._routes.append(r); self._route_by_handler[fn]=r; self._openapi_cache=None
            return fn
        return deco

    def get(self, path:str, *, name:Optional[str]=None, response_model:Optional[Any]=None, internal:bool=False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        return self.route("GET", path, name=name, response_model=response_model, internal=internal, tags=tags, summary=summary, description=description, responses=responses, security=security)

    def post(self, path:str, *, name:Optional[str]=None, response_model:Optional[Any]=None, internal:bool=False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        return self.route("POST", path, name=name, response_model=response_model, internal=internal, tags=tags, summary=summary, description=description, responses=responses, security=security)

    def put(self, path:str, *, name:Optional[str]=None, response_model:Optional[Any]=None, internal:bool=False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        return self.route("PUT", path, name=name, response_model=response_model, internal=internal, tags=tags, summary=summary, description=description, responses=responses, security=security)

    def delete(self, path:str, *, name:Optional[str]=None, response_model:Optional[Any]=None, internal:bool=False, tags: Optional[list[str]] = None, summary: Optional[str] = None, description: Optional[str] = None, responses: Optional[dict[Any, Any]] = None, security: Optional[list[dict[str, list[str]]]] = None):
        return self.route("DELETE", path, name=name, response_model=response_model, internal=internal, tags=tags, summary=summary, description=description, responses=responses, security=security)

    def use(self, mw): self.middleware.add(mw); return mw

    def include_router(self, router: APIRouter, *, prefix: str = "", tags: Optional[list[str]] = None):
        base_prefix = prefix.rstrip("/") if prefix not in ("", "/") else ""
        extra_tags = list(tags or [])
        for rd in router._routes:
            route_path = f"{router.prefix}{rd.path}"
            path = f"{base_prefix}{route_path}" or "/"
            merged_tags = list(dict.fromkeys([*(rd.tags or []), *extra_tags])) or None
            self.route(rd.method, path, name=rd.name, response_model=rd.response_model, internal=rd.internal, tags=merged_tags, summary=rd.summary, description=rd.description, responses=rd.responses, security=rd.security)(rd.handler)

    def on_event(self, event: str):
        if event not in ("startup", "shutdown"):
            raise ValueError("event must be 'startup' or 'shutdown'")
        target = self._startup_handlers if event == "startup" else self._shutdown_handlers
        def deco(fn: Callable[..., Any]):
            target.append(fn)
            return fn
        return deco

    def startup(self, fn: Callable[..., Any]):
        self._startup_handlers.append(fn)
        return fn

    def shutdown(self, fn: Callable[..., Any]):
        self._shutdown_handlers.append(fn)
        return fn

    def exception_handler(self, exc_type: type[BaseException]):
        def deco(fn: Callable[..., Any]):
            self._exception_handlers[exc_type] = fn
            return fn
        return deco

    async def _run_event_handlers(self, handlers: list[Callable[..., Any]]):
        for fn in handlers:
            value = fn()
            if inspect.isawaitable(value):
                await value

    async def _handle_exception(self, req: Request, exc: Exception) -> Response:
        for exc_type in type(exc).mro():
            fn = self._exception_handlers.get(exc_type)
            if fn is None:
                continue
            value = fn(req, exc)
            if inspect.isawaitable(value):
                value = await value
            return self._to_response(value)
        if isinstance(exc, HTTPError):
            return JSONResponse({"error":exc.message,"detail":exc.detail}, status=exc.status)
        if isinstance(exc, TimeoutError):
            return JSONResponse({"error":"Request Timeout"}, status=408)
        return JSONResponse({"error":"Internal Server Error"}, status=500)

    async def _handle(self, req:Request, receive, send)->Response:
        m=self.router.match(req.method, req.path)
        if m is None: return JSONResponse({"error":"Not Found"}, status=404)
        req.path_params=m.params
        route=self._route_by_handler.get(m.handler)
        total = 0

        async def guarded_receive():
            nonlocal total
            while True:
                event=await receive()
                if event.get("type")=="http.request":
                    b=event.get("body", b""); total += len(b)
                    if total>self.max_body_bytes: raise HTTPError(413,"Payload Too Large",{"max_body_bytes":self.max_body_bytes})
                return event

        if route is None:
            res=m.handler(req); 
            if inspect.isawaitable(res): res=await res
        else:
            dep_cache={}
            kwargs, cleanups=await resolve_dependencies(route.param_specs, req=req, receive=guarded_receive, path_param_names=route.path_param_names, validate_body_fn=route.validate_body_fn, dep_cache=dep_cache)
            try:
                res=route.handler(**kwargs)
                if inspect.isawaitable(res): res=await res
                if route.validate_response_fn is not None:
                    if isinstance(res, Response): raise HTTPError(500,"response_model cannot be used with raw Response objects")
                    res=route.validate_response_fn(res)
            finally:
                for cb in reversed(cleanups):
                    value = cb()
                    if inspect.isawaitable(value):
                        await value
        return self._to_response(res)

    def _to_response(self, result:Any)->Response:
        if isinstance(result, Response): return result
        if isinstance(result, (dict,list,int,float,bool)) or result is None: return JSONResponse(result)
        if isinstance(result, str): return TextResponse(result)
        return JSONResponse({"ok":True,"result":str(result)})

    async def __call__(self, scope, receive, send):
        scope_type = scope.get("type")
        if scope_type == "lifespan":
            while True:
                msg = await receive()
                msg_type = msg.get("type")
                if msg_type == "lifespan.startup":
                    try:
                        await self._run_event_handlers(self._startup_handlers)
                        await send({"type": "lifespan.startup.complete"})
                    except Exception as exc:
                        await send({"type": "lifespan.startup.failed", "message": str(exc)})
                elif msg_type == "lifespan.shutdown":
                    try:
                        await self._run_event_handlers(self._shutdown_handlers)
                        await send({"type": "lifespan.shutdown.complete"})
                    except Exception as exc:
                        await send({"type": "lifespan.shutdown.failed", "message": str(exc)})
                    return
            return
        if scope_type!="http": return
        req=Request(scope)
        handler=self.middleware.build(self._final_handler)
        async with self._sem:
            try:
                async with timeout(self.request_timeout):
                    resp=await handler(req, receive, send)
            except Exception as exc:
                resp=await self._handle_exception(req, exc)
            await resp.send(send)

    async def _final_handler(self, req:Request, receive, send)->Response:
        return await self._handle(req, receive, send)

def _extract_security(specs: list[ParamSpec]):
    requirements: list[dict[str, list[str]]] = []
    schemes: dict[str, dict[str, Any]] = {}
    seen_calls: set[Callable[..., Any]] = set()

    def collect_from_call(dep: Callable[..., Any]):
        if dep in seen_calls:
            return
        seen_calls.add(dep)
        req = getattr(dep, "__turbo_security_requirement__", None)
        sch = getattr(dep, "__turbo_security_scheme__", None)
        if isinstance(req, dict):
            requirements.append(req)
        if isinstance(sch, tuple) and len(sch) == 2:
            name, scheme = sch
            if isinstance(name, str) and isinstance(scheme, dict):
                schemes[name] = scheme
        try:
            sig = inspect.signature(dep)
        except (TypeError, ValueError):
            return
        for p in sig.parameters.values():
            default = p.default
            if isinstance(default, Depends):
                collect_from_call(default.call)

    for spec in specs:
        if spec.kind != "dep" or spec.dep is None:
            continue
        collect_from_call(spec.dep.call)
    return (requirements or None), (schemes or None)
