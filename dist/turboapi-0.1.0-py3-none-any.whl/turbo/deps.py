from __future__ import annotations
import inspect
import types
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, get_origin, get_args, Union
from .errors import HTTPError
from .request import Request

@dataclass(frozen=True, slots=True)
class Depends:
    call: Callable[..., Any]
    cache: bool = True

@dataclass(slots=True)
class ParamSpec:
    name: str
    kind: str
    annotation: Any
    default: Any
    dep: Optional[Depends]=None

def unwrap_optional(tp):
    o=get_origin(tp)
    if o in (Union, types.UnionType):
        args=[a for a in get_args(tp) if a is not type(None)]
        return args[0] if args else tp
    return tp

def compile_route_plan(handler: Callable, *, request_type):
    sig=inspect.signature(handler)
    specs=[]
    for name,p in sig.parameters.items():
        ann=p.annotation; default=p.default
        if ann is request_type:
            specs.append(ParamSpec(name,"request",ann,default)); continue
        if isinstance(default, Depends):
            specs.append(ParamSpec(name,"dep",ann,default,default)); continue
        specs.append(ParamSpec(name,"auto",ann,default))
    return specs, sig

async def resolve_dependencies(specs, *, req, receive, path_param_names:set[str], validate_body_fn, dep_cache:Dict[Callable,Any]):
    out={}
    query=req.query_params
    path=req.path_params or {}
    body_cache = None
    cleanups: list[Callable[[], Any]] = []

    async def resolve_dep_call(dep: Depends):
        fn = dep.call
        if dep.cache and fn in dep_cache:
            return dep_cache[fn]
        val = await resolve_callable(fn, req=req, query=query, path=path, receive=receive, path_param_names=path_param_names, dep_cache=dep_cache, cleanups=cleanups)
        if dep.cache:
            dep_cache[fn] = val
        return val

    for s in specs:
        if s.kind=="request":
            out[s.name]=req; continue
        if s.kind=="dep":
            out[s.name]=await resolve_dep_call(s.dep); continue
        kind="path" if s.name in path_param_names else ("body" if (validate_body_fn and s.annotation is not inspect._empty) else "query")
        if kind=="path":
            if s.name not in path: raise HTTPError(400,"Missing path param",{"param":s.name})
            out[s.name]=cast_scalar(path[s.name], s.annotation); continue
        if kind=="query":
            if s.name in query:
                out[s.name]=cast_scalar(query[s.name], s.annotation)
            else:
                if s.default is inspect._empty: raise HTTPError(422,"Missing query param",{"param":s.name})
                out[s.name]=None if s.default is None else s.default
            continue
        if kind=="body":
            if body_cache is None and validate_body_fn:
                body_cache = await validate_body_fn(req, receive)
            body=body_cache
            if body is None: raise HTTPError(422,"Body required")
            out[s.name]=body.get(s.name, body)
            continue
    return out, cleanups

async def resolve_callable(fn: Callable[..., Any], *, req, query: Dict[str, str], path: Dict[str, str], receive, path_param_names: set[str], dep_cache: Dict[Callable, Any], cleanups: list[Callable[[], Any]]):
    sig = inspect.signature(fn)
    kwargs: dict[str, Any] = {}
    for name, p in sig.parameters.items():
        ann = p.annotation
        default = p.default
        if ann is Request or ann == "Request":
            kwargs[name] = req
            continue
        if isinstance(default, Depends):
            dep_fn = default.call
            if default.cache and dep_fn in dep_cache:
                kwargs[name] = dep_cache[dep_fn]
                continue
            dep_val = await resolve_callable(dep_fn, req=req, query=query, path=path, receive=receive, path_param_names=path_param_names, dep_cache=dep_cache, cleanups=cleanups)
            if default.cache:
                dep_cache[dep_fn] = dep_val
            kwargs[name] = dep_val
            continue
        source = "path" if name in path_param_names else "query"
        if source == "path":
            if name not in path:
                raise HTTPError(422, "Missing dependency parameter", {"param": name})
            kwargs[name] = cast_scalar(path[name], ann)
            continue
        if name in query:
            kwargs[name] = cast_scalar(query[name], ann)
            continue
        if default is inspect._empty:
            raise HTTPError(422, "Missing dependency parameter", {"param": name})
        kwargs[name] = default

    result = fn(**kwargs)
    if inspect.isawaitable(result):
        result = await result
    if inspect.isasyncgen(result):
        try:
            value = await anext(result)
        except StopAsyncIteration:
            raise HTTPError(500, "Dependency generator did not yield a value")
        cleanups.append(result.aclose)
        return value
    if inspect.isgenerator(result):
        try:
            value = next(result)
        except StopIteration:
            raise HTTPError(500, "Dependency generator did not yield a value")
        cleanups.append(result.close)
        return value
    return result

def cast_scalar(raw:str, ann):
    if ann is inspect._empty or ann is None: return raw
    ann=unwrap_optional(ann)
    try:
        if ann is str: return raw
        if ann is int: return int(raw)
        if ann is float: return float(raw)
        if ann is bool:
            v=raw.lower().strip()
            if v in ("true","1","yes","y","on"): return True
            if v in ("false","0","no","n","off"): return False
            raise ValueError()
    except Exception:
        raise HTTPError(422,"Invalid parameter type",{"value":raw,"expected":str(ann)})
    return raw
